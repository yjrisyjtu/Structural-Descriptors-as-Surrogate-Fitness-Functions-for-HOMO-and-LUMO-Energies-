"""
Worker module pour l'analyse Hückel×Clar en parallèle.
Doit être un fichier .py séparé (requis par multiprocessing sur macOS).
"""
import os, sys
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import rdchem
import pulp

# ── Import Clar V4 au niveau module (évite l'import répété dans chaque appel) ──
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clar_v4 import compute_clar_v4, get_aromatic_6rings

# ── Paramètres Hückel ─────────────────────────────────────────────────────
PI_ELECTRONS = {'B0':0,'C1':1,'C2':2,'N1':1,'N2':2,'O1':1,'O2':2,
                'S1':1,'S2':2,'P1':1,'P2':2,'F2':2,'Cl2':2,'Br2':2,'I2':2}
H_DIAG = {'B0':-0.45,'C1':0.00,'C2':2.00,'N1':0.51,'N2':1.37,
           'O1':0.97,'O2':2.09,'S1':0.46,'S2':1.11,'P1':0.19,'P2':0.75,
           'F2':2.71,'Cl2':1.48,'Br2':1.20,'I2':1.00}
_RAW_COUPLINGS = {
    ('C1','C1'):1.00,('B0','C1'):0.73,('B0','B0'):0.87,
    ('N1','C1'):1.02,('N1','B0'):0.66,('N1','N1'):1.09,
    ('N2','C1'):0.89,('N2','B0'):0.53,('N2','N1'):0.99,('N2','N2'):0.98,
    ('O1','C1'):1.06,('O1','B0'):0.60,('O1','N1'):1.14,('O1','N2'):1.13,('O1','O1'):1.26,
    ('O2','C1'):0.66,('O2','B0'):0.35,('O2','N1'):0.80,('O2','N2'):0.89,
    ('O2','O1'):1.02,('O2','O2'):0.95,
    ('F2','C1'):0.52,('S1','C1'):0.81,('S1','S1'):0.68,
    ('S2','C1'):0.69,('Cl2','C1'):0.62,
    ('C2','C1'):0.70,('C2','C2'):0.25,
    ('P1','C1'):0.77,('P2','C1'):0.76,
    ('Br2','C1'):0.62,('I2','C1'):0.62,
}
COUPLING_TABLE = {}
for (_a, _b), _v in _RAW_COUPLINGS.items():
    COUPLING_TABLE[(_a, _b)] = _v
    COUPLING_TABLE[(_b, _a)] = _v

HALOGENS    = {'F', 'Cl', 'Br'}
HETERO_MAIN = {'N', 'O', 'S', 'P'}

CLAR_PRIORITY = {'fix_sextet': 0, 'mig_sextet': 1, '4pi': 1, 'shared_2pi': 2, '2pi': 3, '0pi': 4}
CLAR_TYPES    = ['fix_sextet', 'mig_sextet', 'shared_2pi', '2pi', '0pi']


# ── Fonctions Hückel ──────────────────────────────────────────────────────
def _kekulized_mol(mol):
    kmol = Chem.Mol(mol)
    Chem.Kekulize(kmol, clearAromaticFlags=True)
    return kmol

def _atom_has_pi_bond(atom):
    for bond in atom.GetBonds():
        if bond.GetBondType() in (rdchem.BondType.DOUBLE, rdchem.BondType.TRIPLE):
            return True
    return False

def _classify_atom(atom):
    sym = atom.GetSymbol()
    in_pi = _atom_has_pi_bond(atom)
    if sym == 'B':  return 'B0'
    if sym == 'C':  return 'C1' if in_pi else 'C2'
    if sym in HETERO_MAIN: return f'{sym}1' if in_pi else f'{sym}2'
    if sym in HALOGENS: return f'{sym}2'
    raise ValueError(f'Unsupported atom: {sym}')

def _atom_types(mol):
    kmol = _kekulized_mol(mol)
    return [_classify_atom(a) for a in kmol.GetAtoms()]

def solve_huckel(mol):
    """Accepte un objet mol RDKit (évite un double MolFromSmiles)."""
    if mol is None:
        return None
    atom_types = _atom_types(mol)
    n = mol.GetNumAtoms()
    H = np.zeros((n, n))
    for i, t in enumerate(atom_types):
        H[i, i] = H_DIAG[t]
    for bond in mol.GetBonds():
        i, j = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        k = (atom_types[i], atom_types[j])
        if k not in COUPLING_TABLE:
            return None
        H[i, j] = H[j, i] = COUPLING_TABLE[k]
    lam, vecs = np.linalg.eigh(H)
    order = np.argsort(-lam)
    eigvals = lam[order]
    eigvecs = vecs[:, order]
    n_elec = sum(PI_ELECTRONS[t] for t in atom_types)
    occs = np.zeros(len(eigvals), dtype=int)
    rem = n_elec
    for i in range(len(eigvals)):
        take = min(rem, 2); occs[i] = take; rem -= take
        if rem == 0:
            break
    occ_idx  = np.where(occs > 0)[0]
    virt_idx = np.where(occs == 0)[0]
    hi = int(occ_idx[-1])  if len(occ_idx)  else None
    li = int(virt_idx[0])  if len(virt_idx) else None
    return dict(mol=mol, n_atoms=n, atom_types=atom_types, n_pi_electrons=int(n_elec),
                eigenvalues=eigvals, eigenvectors=eigvecs, occupations=occs,
                homo_index=hi, lumo_index=li,
                homo_lambda=float(eigvals[hi]) if hi is not None else None,
                lumo_lambda=float(eigvals[li]) if li is not None else None)


# ── Analyse combinée (UN SEUL calcul Clar par molécule) ──────────────────
def analyze_huckel_clar(smiles):
    """Attribution par priorité (fix > mig > 2pi > 0pi) : 1 atome → 1 type.
    N'appelle compute_clar_v4 qu'une seule fois (suppression du doublon
    label_rings_clar + assign_atom_clar_types qui le calculait deux fois).
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, None, []

    huckel = solve_huckel(mol)          # mol déjà parsé, pas de double MolFromSmiles
    if huckel is None:
        return None, None, []

    # ── UN SEUL appel ILP ────────────────────────────────────────────────
    res   = compute_clar_v4(mol)
    rings = get_aromatic_6rings(mol)
    ring_labels = res['ring_labels']

    # Assignation atome → type Clar (priorité fix > mig > shared_2pi > 2pi > 0pi)
    atom_clar = {}
    for i, (atoms, _bonds) in enumerate(rings):
        label = ring_labels[i]
        if label not in CLAR_PRIORITY:
            continue
        for atom in atoms:
            if (atom not in atom_clar
                    or CLAR_PRIORITY[label] < CLAR_PRIORITY[atom_clar[atom]]):
                atom_clar[atom] = label
    for bid in res['fixed_shared_bonds']:
        bond = mol.GetBondWithIdx(bid)
        for atom_idx in [bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()]:
            if atom_clar.get(atom_idx) in ('2pi', '0pi', None):
                atom_clar[atom_idx] = 'shared_2pi'

    # ── Coefficients Hückel ──────────────────────────────────────────────
    hi, li = huckel['homo_index'], huckel['lumo_index']
    vecs   = huckel['eigenvectors']
    c_homo = vecs[:, hi] if hi is not None else np.zeros(huckel['n_atoms'])
    c_lumo = vecs[:, li] if li is not None else np.zeros(huckel['n_atoms'])
    total_homo = float((c_homo ** 2).sum()) or 1.0
    total_lumo = float((c_lumo ** 2).sum()) or 1.0
    n_atoms = huckel['n_atoms']

    rows = []
    for idx in range(n_atoms):
        ct = atom_clar.get(idx)
        if ct is None:
            continue
        rows.append({'atom_idx': idx, 'clar_type': ct,
                     'c2_homo': float(c_homo[idx] ** 2),
                     'c2_lumo': float(c_lumo[idx] ** 2),
                     'weight': 1.0})
    df = pd.DataFrame(rows)

    stats = (
        df.groupby('clar_type')
          .agg(n_atoms=('weight', 'sum'),
               sum_c2_homo=('c2_homo', 'sum'),
               sum_c2_lumo=('c2_lumo', 'sum'))
          .assign(frac_atoms=lambda x: x['n_atoms'] / n_atoms,
                  frac_homo =lambda x: x['sum_c2_homo'] / total_homo,
                  frac_lumo =lambda x: x['sum_c2_lumo'] / total_lumo)
    )
    stats['loc_homo'] = stats['frac_homo'] / stats['frac_atoms']
    stats['loc_lumo'] = stats['frac_lumo'] / stats['frac_atoms']

    return df, stats, ring_labels


# ── Fonction worker (appelée par chaque processus) ────────────────────────
def process_row(row_dict):
    smi = row_dict['SMILES']
    try:
        _, stats_df, _ring_labels = analyze_huckel_clar(smi)
        if stats_df is None:
            return {'_error': 'analyze_returned_None', 'ID': row_dict['ID']}

        n_shared_2pi_atoms = (int(stats_df.loc['shared_2pi', 'n_atoms'])
                              if 'shared_2pi' in stats_df.index else 0)
        rec = {
            'ID'                 : row_dict['ID'],
            'SMILES'             : smi,
            'clar_fix'           : row_dict['clar_fix'],
            'clar_mig'           : row_dict['clar_mig'],
            'clar_4pi'           : row_dict['clar_4pi'],
            'HOMO_eV'            : row_dict['HOMO_eV'],
            'LUMO_eV'            : row_dict['LUMO_eV'],
            'GAP_eV'             : row_dict['GAP_eV'],
            'n_shared_2pi_atoms' : n_shared_2pi_atoms,
        }
        for ct in CLAR_TYPES:
            if ct in stats_df.index:
                rec[f'frac_atoms_{ct}'] = stats_df.loc[ct, 'frac_atoms']
                rec[f'frac_homo_{ct}']  = stats_df.loc[ct, 'frac_homo']
                rec[f'frac_lumo_{ct}']  = stats_df.loc[ct, 'frac_lumo']
                rec[f'loc_homo_{ct}']   = stats_df.loc[ct, 'loc_homo']
                rec[f'loc_lumo_{ct}']   = stats_df.loc[ct, 'loc_lumo']
            else:
                for prefix in ['frac_atoms_', 'frac_homo_', 'frac_lumo_',
                                'loc_homo_', 'loc_lumo_']:
                    rec[f'{prefix}{ct}'] = 0.0
        return rec
    except Exception as e:
        return {'_error': str(e), 'ID': row_dict['ID'], 'SMILES': smi}
