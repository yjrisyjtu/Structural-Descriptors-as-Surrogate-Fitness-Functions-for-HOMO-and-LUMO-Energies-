"""
heteroatom_pi_connections.py
────────────────────────────
Détection des connexions Donneur–π–Accepteur dans les molécules SMILES.

DÉFINITIONS
───────────
Donneur (D) :
    Hétéroatome (O, N, S, Se, P) portant un doublet disponible pour
    la donation dans le système π. Critères :
      • Lié à un carbone π par une liaison simple (bt=1) → amines, éthers, thioéthers
      • Lié à un carbone π par une liaison aromatique hétéroatome-C
        uniquement si le N est PYRROLIQUE (lone pair dans le π) :
        N a un H ou au moins une liaison non-aromatique
      • O et S aromatiques (furane, thiophène) → donneurs
      • Exclus : N pyridinic pur (toutes liaisons aromatiques, sans H)
        car son doublet est dans le plan σ, pas disponible pour le π

Accepteur (A) :
    CARBONE π lié à un hétéroatome par liaison double (=) ou triple (≡).
      • C=O, C=S, C=N (imines, amides), C=Se
      • C≡N (nitrile)
      • C=N aromatique (N pyridinic adjacent à ce carbone dans un cycle)
        → car en représentation Kekulé ce C porte la double liaison C=N

Pont π :
    Chemin passant UNIQUEMENT par des CARBONES π (carbones impliqués dans
    au moins une liaison double, triple ou aromatique) reliés entre eux par
    des liaisons C–C (simples, doubles ou aromatiques, toutes autorisées).
    On rapporte le PLUS LONG chemin simple entre le C porteur du donneur
    et le C accepteur.

FORMAT DE SORTIE
────────────────
  D:{Sym}({Sym}-C) -π[NC]- A:{label}
  ex : D:N(N-C) -π[6C]- A:C=O
  ex : D:O(O-C) -π[3C]- A:C≡N
  ex : D:N(N(pyr)-C) -π[1C]- A:C=N(arom)
"""

import csv
from itertools import product
from collections import defaultdict

from rdkit import Chem
import networkx as nx
from tqdm.auto import tqdm


# ══════════════════════════════════════════════════════════════════════════════
# Constantes
# ══════════════════════════════════════════════════════════════════════════════

HETEROATOMS = {'O', 'N', 'S', 'Se', 'P'}


# ══════════════════════════════════════════════════════════════════════════════
# Graphe π carboné
# ══════════════════════════════════════════════════════════════════════════════

def _is_pi_carbon(atom):
    """
    Un carbone est π s'il participe à au moins une liaison
    double, triple ou aromatique.
    """
    if atom.GetSymbol() != 'C':
        return False
    for bond in atom.GetBonds():
        if bond.GetBondTypeAsDouble() >= 2.0 or bond.GetIsAromatic():
            return True
    return False


def build_pi_carbon_graph(mol):
    """
    Construit le graphe de conjugaison π restreint aux carbones.

    Nœuds  : carbones π
    Arêtes : toute liaison C–C entre deux carbones π
             (liaison simple entre 2 C-π = conjugaison par alternance,
              double, ou aromatique)

    Retourne (G, pi_carbons) où pi_carbons est l'ensemble des indices.
    """
    pi_c = {a.GetIdx() for a in mol.GetAtoms() if _is_pi_carbon(a)}

    G = nx.Graph()
    G.add_nodes_from(pi_c)

    for bond in mol.GetBonds():
        i1 = bond.GetBeginAtomIdx()
        i2 = bond.GetEndAtomIdx()
        if i1 in pi_c and i2 in pi_c:
            G.add_edge(i1, i2)

    return G, pi_c


# ══════════════════════════════════════════════════════════════════════════════
# Classification des N aromatiques
# ══════════════════════════════════════════════════════════════════════════════

def _is_n_pyridinic(atom):
    """
    N pyridinic (type pyridine) : doublet dans le plan σ → ACCEPTEUR.
    Critère : N aromatique, sans H, toutes ses liaisons sont aromatiques.
    Exemples : pyridine, pyrimidine, pyrazine, N de pyrazole sans H.
    """
    if atom.GetSymbol() != 'N' or not atom.GetIsAromatic():
        return False
    has_H     = atom.GetTotalNumHs() > 0
    all_arom  = all(b.GetIsAromatic() for b in atom.GetBonds())
    return all_arom and not has_H


def _is_n_pyrrolique(atom):
    """
    N pyrrolique (type pyrrole) : doublet dans le π → DONNEUR.
    Critère : N aromatique ET (a un H OU a au moins une liaison non-aromatique).
    Exemples : pyrrole NH, indole NH, N de pyrazole avec substituant alkyle.
    """
    if atom.GetSymbol() != 'N' or not atom.GetIsAromatic():
        return False
    return not _is_n_pyridinic(atom)


# ══════════════════════════════════════════════════════════════════════════════
# Identification des donneurs
# ══════════════════════════════════════════════════════════════════════════════

def get_donors(mol, pi_c):
    """
    Retourne la liste de tous les points d'ancrage donneur :
    (hétéroatome D) → (carbone π voisin).

    Chaque entrée : dict {sym, hidx, cidx, label}
      sym   : symbole de l'hétéroatome
      hidx  : index de l'hétéroatome
      cidx  : index du carbone π porteur
      label : label descriptif du type de donation
    """
    donors = []
    seen   = set()

    for atom in mol.GetAtoms():
        sym  = atom.GetSymbol()
        hidx = atom.GetIdx()

        if sym not in HETEROATOMS:
            continue

        for bond in atom.GetBonds():
            nb   = bond.GetOtherAtom(atom)
            nidx = nb.GetIdx()

            # Le voisin doit être un carbone π
            if nb.GetSymbol() != 'C' or nidx not in pi_c:
                continue

            bt      = bond.GetBondTypeAsDouble()
            is_arom = bond.GetIsAromatic()

            label = None

            if bt == 1.0:
                # Liaison simple hétéroatome→C π : tous les hétéroatomes qualifient
                label = f"{sym}-C"

            elif is_arom:
                # Liaison aromatique hétéroatome–C
                if sym == 'N':
                    if _is_n_pyrrolique(atom):
                        label = "N(pyr)-C"
                    # N pyridinic exclu des donneurs
                elif sym in ('O', 'S'):
                    # O de furane, S de thiophène → donneurs
                    label = f"{sym}(arom)-C"

            if label is not None:
                key = (hidx, nidx)
                if key not in seen:
                    seen.add(key)
                    donors.append({
                        'sym'  : sym,
                        'hidx' : hidx,
                        'cidx' : nidx,
                        'label': label,
                    })

    return donors


# ══════════════════════════════════════════════════════════════════════════════
# Identification des accepteurs
# ══════════════════════════════════════════════════════════════════════════════

def get_acceptors(mol, pi_c):
    """
    Retourne la liste des carbones π accepteurs :
    carbone π lié à un hétéroatome par liaison double ou triple,
    ou carbone aromatique adjacent à un N pyridinic.

    Chaque entrée : dict {cidx, hetero_sym, hidx, label}
      cidx      : index du carbone accepteur
      hetero_sym: symbole de l'hétéroatome lié
      hidx      : index de l'hétéroatome
      label     : ex "C=O", "C≡N", "C=N(arom)"
    """
    acceptors = []
    seen      = set()

    for atom in mol.GetAtoms():
        if atom.GetSymbol() != 'C' or atom.GetIdx() not in pi_c:
            continue
        cidx = atom.GetIdx()

        for bond in atom.GetBonds():
            nb   = bond.GetOtherAtom(atom)
            hidx = nb.GetIdx()

            if nb.GetSymbol() not in HETEROATOMS:
                continue

            bt      = bond.GetBondTypeAsDouble()
            is_arom = bond.GetIsAromatic()

            label = None

            if bt == 3.0:
                # Triple liaison C≡N
                label = f"C\u2261{nb.GetSymbol()}"

            elif bt == 2.0:
                # Double liaison C=X
                label = f"C={nb.GetSymbol()}"

            elif is_arom and nb.GetSymbol() == 'N' and _is_n_pyridinic(nb):
                # C aromatique adjacent à N pyridinic
                label = "C=N(arom)"

            if label is not None:
                key = (cidx, hidx)
                if key not in seen:
                    seen.add(key)
                    acceptors.append({
                        'cidx'      : cidx,
                        'hetero_sym': nb.GetSymbol(),
                        'hidx'      : hidx,
                        'label'     : label,
                    })

    return acceptors


# ══════════════════════════════════════════════════════════════════════════════
# Plus long chemin π
# ══════════════════════════════════════════════════════════════════════════════

def _longest_pi_path(G, src, dst, cutoff=30):
    """
    Retourne le plus long chemin simple entre src et dst dans le graphe π carboné.
    Renvoie None si aucun chemin n'existe.
    cutoff : longueur maximale explorée (protection contre les très grands systèmes).
    """
    if src == dst:
        return [src]
    if not G.has_node(src) or not G.has_node(dst):
        return None
    try:
        all_paths = nx.all_simple_paths(G, src, dst, cutoff=cutoff)
        best = max(all_paths, key=len, default=None)
        return best
    except (nx.NetworkXError, nx.NodeNotFound):
        return None


# ══════════════════════════════════════════════════════════════════════════════
# Détection principale
# ══════════════════════════════════════════════════════════════════════════════

def find_da_pi_connections(smiles):
    """
    Détecte toutes les connexions D–π–A dans la molécule.

    Pour chaque paire (donneur, accepteur), on cherche le plus long chemin
    de carbones π entre le carbone porteur du donneur et le carbone accepteur.

    Déduplication : pour une même paire (hidx_D, cidx_A, hidx_A), un seul
    résultat est gardé — celui correspondant au chemin le plus long
    (en agrégeant sur tous les cidx_D possibles d'un même hétéroatome D).

    Retourne une liste de dict :
      donor    : dict donneur
      acceptor : dict accepteur
      path     : liste d'indices de carbones π du chemin
      n_c      : len(path) = nombre de carbones dans le pont
      connection: chaîne formatée
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return []

    G, pi_c   = build_pi_carbon_graph(mol)
    donors    = get_donors(mol, pi_c)
    acceptors = get_acceptors(mol, pi_c)

    if not donors or not acceptors:
        return []

    # Agrégation : pour chaque (hidx_D, cidx_A, hidx_A) → meilleur (plus long) chemin
    # On regroupe d'abord toutes les paires candidates
    best: dict = {}  # (hidx_D, cidx_A, hidx_A) → (path, donor, acceptor)

    for d, a in product(donors, acceptors):
        # Un hétéroatome ne peut pas être à la fois D et A pour la même paire
        if d['hidx'] == a['hidx']:
            continue

        path = _longest_pi_path(G, d['cidx'], a['cidx'])
        if path is None:
            continue

        key = (d['hidx'], a['cidx'], a['hidx'])
        if key not in best or len(path) > len(best[key][0]):
            best[key] = (path, d, a)

    # Construction des résultats
    connections = []
    for (hidx_D, cidx_A, hidx_A), (path, d, a) in best.items():
        n_c = len(path)
        if n_c == 1:
            tag = "[1C]"
        else:
            tag = f"\u03c0[{n_c}C]"
        conn_str = f"D:{d['sym']}({d['label']}) -{tag}- A:{a['label']}"
        connections.append({
            'donor'     : d,
            'acceptor'  : a,
            'path'      : path,
            'n_c'       : n_c,
            'connection': conn_str,
        })

    # Trier par longueur décroissante du pont π
    connections.sort(key=lambda x: -x['n_c'])
    return connections


# ══════════════════════════════════════════════════════════════════════════════
# Formatage CSV
# ══════════════════════════════════════════════════════════════════════════════

def format_for_csv(connections):
    """
    Retourne (count, all_connections_str, unique_types_str, longest_path_n).

    all_connections_str : connexions séparées par '|'
    unique_types_str    : types simplifiés uniques (D_sym-π-A_label) séparés par ';'
    longest_path_n      : longueur du plus long pont π (nb de carbones)
    """
    if not connections:
        return 0, '', '', 0

    count        = len(connections)
    all_conn     = '|'.join(c['connection'] for c in connections)
    longest      = connections[0]['n_c']  # déjà trié par décroissant

    type_set = set()
    for c in connections:
        type_set.add(f"{c['donor']['sym']}-\u03c0-{c['acceptor']['label']}")

    return count, all_conn, ';'.join(sorted(type_set)), longest


# ══════════════════════════════════════════════════════════════════════════════
# Comptage D/A dans le plus grand système π
# ══════════════════════════════════════════════════════════════════════════════

def count_da_in_largest_pi_system(smiles):
    """
    Compte le nombre de groupements donneurs et accepteurs dans la
    plus grande composante connexe du graphe π carboné.

    Donneur  : hétéroatome unique (hidx) dont le carbone d'ancrage (cidx)
               appartient à la plus grande composante.
    Accepteur: hétéroatome unique (hidx) lié par =/ à un carbone π (cidx)
               de la plus grande composante.

    Retourne (d_count, a_count, largest_pi_size).
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return 0, 0, 0

    G, pi_c = build_pi_carbon_graph(mol)
    if not pi_c:
        return 0, 0, 0

    components = list(nx.connected_components(G))
    if not components:
        return 0, 0, 0
    largest = max(components, key=len)

    donors    = get_donors(mol, pi_c)
    acceptors = get_acceptors(mol, pi_c)

    d_count = len({d['hidx'] for d in donors    if d['cidx'] in largest})
    a_count = len({a['hidx'] for a in acceptors if a['cidx'] in largest})

    return d_count, a_count, len(largest)


# ══════════════════════════════════════════════════════════════════════════════
# Traitement CSV
# ══════════════════════════════════════════════════════════════════════════════

def _find_smiles_column(fieldnames):
    """
    Cherche la colonne SMILES dans le CSV de manière insensible à la casse.
    Retourne le nom exact de la colonne trouvée, ou None.
    Priorité : 'SMILES' > 'Smiles' > 'smiles' > 'smi' > 'canonical_smiles' > ...
    """
    candidates = ['SMILES', 'Smiles', 'smiles', 'SMI', 'Smi', 'smi',
                  'canonical_smiles', 'Canonical_Smiles', 'CANONICAL_SMILES',
                  'structure', 'Structure', 'mol', 'Mol', 'MOL']
    for c in candidates:
        if c in fieldnames:
            return c
    # Recherche floue : n'importe quel champ contenant "smil"
    for f in fieldnames:
        if 'smil' in f.lower() or 'smi' == f.lower():
            return f
    return None


def _diagnose_zero(smiles, mol, pi_c, donors, acceptors):
    """
    Retourne un message explicatif quand 0 connexion est détecté.
    """
    if mol is None:
        return 'SMILES invalide (RDKit ne peut pas parser)'
    if not pi_c:
        return 'Aucun carbone π trouvé (molécule sans double liaison ni cycle aromatique)'
    if not donors:
        msg = 'Aucun donneur détecté.'
        hetero_in_pi = [a for a in mol.GetAtoms()
                        if a.GetSymbol() in ('N','O','S','Se','P')
                        and any(b.GetOtherAtom(a).GetIdx() in pi_c for b in a.GetBonds())]
        if not hetero_in_pi:
            msg += ' Aucun hétéroatome lié à un carbone π.'
        else:
            msg += ' Les hétéroatomes proches du π sont soit pyridinic (N sans H, all arom), soit liés par liaison double (donc accepteurs).'
        return msg
    if not acceptors:
        return 'Aucun accepteur détecté. Pas de C=O, C=S, C=N, C≡N dans le système π, et pas de N pyridinic adjacent à un carbone π.'
    return 'Donneurs et accepteurs présents mais aucun chemin C-C π ne les relie (systèmes π disjoints ?)'


def process_csv(input_csv_path, output_csv_path):
    """
    Lit le CSV d'entrée et ajoute les colonnes D–π–A.

    La colonne SMILES est détectée automatiquement (insensible à la casse).
    Noms reconnus : SMILES, Smiles, smiles, smi, canonical_smiles, etc.

    Nouvelles colonnes :
      DA_PI_COUNT       : nombre de paires D–π–A détectées
      DA_PI_CONNECTIONS : détail de chaque paire (séparées par |)
      UNIQUE_DA_PI_TYPES: types simplifiés uniques (séparés par ;)
      DA_PI_LONGEST     : longueur du plus long pont π (nb de carbones)
      DA_PI_DIAGNOSTIC  : message explicatif si 0 connexion (aide au débogage)
    """
    # Compte le nombre total de lignes pour la barre de progression
    with open(input_csv_path, 'r', encoding='utf-8') as f:
        n_total = sum(1 for _ in f) - 1  # -1 pour l'en-tête

    rows_out = []
    with open(input_csv_path, 'r', encoding='utf-8') as f:
        reader     = csv.DictReader(f)
        fieldnames = list(reader.fieldnames)

        # Détection automatique de la colonne SMILES
        smiles_col = _find_smiles_column(fieldnames)
        if smiles_col is None:
            raise ValueError(
                "Colonne SMILES introuvable dans le CSV. "
                "Colonnes disponibles : " + str(fieldnames) + ". "
                "Renommez votre colonne en SMILES ou utilisez l'un des noms reconnus : "
                "SMILES, Smiles, smiles, smi, canonical_smiles."
            )
        if smiles_col != 'SMILES':
            print(f"ℹ Colonne SMILES détectée : '{smiles_col}'")

        new_cols   = ['DA_PI_COUNT', 'DA_PI_CONNECTIONS',
                      'UNIQUE_DA_PI_TYPES', 'DA_PI_LONGEST',
                      'D_COUNT_LARGEST', 'A_COUNT_LARGEST']
        out_fields = fieldnames + new_cols

        n_zero = 0
        for row in tqdm(reader, total=n_total, desc="Analyse D–π–A", unit="mol"):
            smiles = row.get(smiles_col, '').strip()
            try:
                conns  = find_da_pi_connections(smiles)
                count, all_conn, utypes, longest = format_for_csv(conns)
                d_count, a_count, _ = count_da_in_largest_pi_system(smiles)

                if count == 0:
                    n_zero += 1
            except Exception:
                count, all_conn, utypes, longest = 0, '', '', 0
                d_count, a_count = 0, 0

            row['DA_PI_COUNT']        = count
            row['DA_PI_CONNECTIONS']  = all_conn
            row['UNIQUE_DA_PI_TYPES'] = utypes
            row['DA_PI_LONGEST']      = longest
            row['D_COUNT_LARGEST']    = d_count
            row['A_COUNT_LARGEST']    = a_count
            rows_out.append(row)

    with open(output_csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=out_fields)
        writer.writeheader()
        writer.writerows(rows_out)

    print(f"✓ {len(rows_out)} molécules → {output_csv_path}")
    if n_zero:
        print(f"⚠ {n_zero} molécule(s) sans connexion D–π–A")
    return rows_out, out_fields


# ══════════════════════════════════════════════════════════════════════════════
# Tests
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    tests = [
        # Molécules problématiques rapportées
        ('[H]c1nc(N([H])[H])c(OC([H])(F)F)c([H])c1-c1nn(C2([H])C([H])([H])C([H])([H])C([H])([H])C2([H])[H])c([C@@]2([H])[C@]3([H])C([H])([H])N(C4([H])C([H])([H])OC4([H])[H])C([H])([H])[C@]23[H])c1[H]',
         'MOL1 – pyrazole N-N'),
        ('[H]c1nc(N([H])[H])nc(C(F)(F)F)c1-c1nc(N2C([H])([H])C([H])([H])OC([H])([H])C2([H])[H])nc(N2C([H])([H])C([H])([H])OC([H])([H])C2([H])[H])c1[H]',
         'MOL2'),
        ('[H]c1c(N(C([H])([H])[H])C([H])([H])[H])c([H])c2c([H])c(C([H])([H])C([H])([H])[H])c(C([H])([H])C([H])([H])[H])nc2c1[H]',
         'MOL3'),
        ('[H]c1nc(N([H])c2c([H])c([H])c3nc(-c4c([H])c(Cl)c([H])c(Cl)c4[H])n([H])c3c2[H])c2c([H])c([H])c([H])c([H])c2n1',
         'MOL4'),
        ('[H]c1c([H])c(N([H])c2nc3c([H])c([H])c(C([H])([H])[H])c([H])c3c([H])c2C#N)c(OC([H])([H])[H])c([H])c1OC([H])([H])[H]',
         'MOL5 – C≡N'),
        ('[H]c1sc(C(C#N)=C(c2c([H])c([H])c(OC([H])([H])C([H])([H])N(C([H])([H])[H])C([H])([H])[H])c([H])c2[H])c2c([H])c([H])c(OC([H])([H])C([H])([H])N(C([H])([H])[H])C([H])([H])[H])c([H])c2[H])c([H])c1[H]',
         'MOL6 – S + C≡N'),
        ('[H]c1c([H])c(-c2c([H])c([H])c(S(=O)(=O)N([H])C3=C(c4nc5c([H])c([H])c([H])c([H])c5s4)[C@@]4([H])C([H])([H])C([H])([H])C([H])([H])C([H])([H])[C@@]4([H])S3)c([H])c2[H])c([H])c([H])c1OC([H])([H])[H]',
         'MOL7'),
        # CSV d'origine
        ('[H]/C(=C1\\C(=O)N([H])C(=O)N1[H])c1c([H])c([H])c(OC([H])([H])C([H])([H])C2([H])C([H])([H])C([H])([H])C([H])([H])C([H])([H])C2([H])[H])c([H])c1[H]',
         'CHEMBL606032 – O-π-C=O'),
        ('[H]/C(=N\\N([H])C(=S)N([H])[H])c1nc2c([H])c([H])c([H])c([H])c2c([H])c1[H]',
         'CHEMBL215065 – N-π-C=S'),
        ('[H]OC(C([H])([H])[H])(C([H])([H])[H])[C@]([H])(c1c([H])c([H])c([H])c([H])c1[H])N([H])C(=O)N([H])c1nc([H])c2c(N3C([H])([H])[C@@]4([H])OC([H])([H])[C@]3([H])C4([H])[H])nn([H])c2c1[H]',
         'CHEMBL3914678 – N-π-C=O'),
    ]

    print(f"{'Molécule':<42} {'#':>3}  {'Plus long':>10}  Types")
    print('─' * 90)
    for smi, name in tests:
        conns = find_da_pi_connections(smi)
        count, _, utypes, longest = format_for_csv(conns)
        print(f"{name:<42} {count:>3}  {longest:>9}C  {utypes or '—'}")
        for c in conns:
            print(f"    {c['connection']}")
